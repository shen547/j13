#!/bin/bash
docker run -p 80:5000 --name yoda -d 204065533127.dkr.ecr.ap-northeast-1.amazonaws.com/cc104devops-repo:latest
